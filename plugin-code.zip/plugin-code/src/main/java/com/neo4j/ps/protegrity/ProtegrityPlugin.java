package com.neo4j.ps.protegrity;

import java.util.*;
import java.util.stream.*;

import org.neo4j.graphdb.*;
import org.neo4j.procedure.*;
import org.neo4j.logging.*;

import com.protegrity.ap.java.*;

public class ProtegrityPlugin
{

        @Context public GraphDatabaseService db;
        @Context public Log log;
        @Context public Transaction curTxn;


        @UserFunction("Protegrity.protectData")
        @Description("protectData - this function calls Protegrity to protect data according to the specified protection data element by name")
        public String protectData(
                        // @Name("UserName") String _username,
                        @Name("DataElement") String _dataElement,
                        @Name("DataValue") String _dataValue,
                        @Name(value = "doDebug", defaultValue = "true") Boolean doDebug
                        ) 
	{
		// initialize variables for Protegrity
		String[] inputStringArray = new String[1];
        String[] ProtectStringArray = new String[1];
		String protectedString = null;

		// instantiate call to protegrity protector
                Protector protector = null;
		try {
			protector = Protector.getProtector();
			if (doDebug) log.info("Protegrity Protector Instantiated");
		}
		catch (Exception e) {
			log.info("Couldn't create instantiate Protegrity Protector: %s",e);
		}

		// create a protegrity session
        SessionObject session = null;
		try {
			// get a protegrity session...hard coding the username to "neo4j" since that is the OS username
            // that the database (and protegrity application protector elements) is running under
            session = protector.createSession("neo4j");
			if (doDebug) log.info("Protegrity session created");
		}
		catch (Exception e) {
			log.info("Couldn't create create session with Protegrity: %s",e);
        }


		// call Protegrity to encrypt/protect data
                inputStringArray[0] = _dataValue;
		try {
			if(!protector.protect(session,_dataElement,inputStringArray,ProtectStringArray))
				log.info("Call to Protegrity protect API failed for element '%s' and value '%s'!!! \nError :%s",_dataElement,inputStringArray[0],protector.getLastError(session));
			protectedString = ProtectStringArray[0];
			if (doDebug) log.info("Call to Protegrity protect API succeeded for element '%s' and value '%s' --> protected value: '%s'!!!",_dataElement,inputStringArray[0],protectedString);
		}
                catch (Exception e) {
                        log.info("Couldn't invoke data proection using element '%s' and value '%s' -> error: %s",_dataElement,inputStringArray[0],e);
                }

		return protectedString;
	}





        @UserFunction("Protegrity.unprotectData")
        @Description("unprotectData - this function calls Protegrity to unprotect data according to the specified protection data element by name")
        public String unprotectData(
                        // @Name("UserName") String _username,
                        @Name("DataElement") String _dataElement,
                        @Name("ProtectedValue") String _protectedValue,
                        @Name(value = "doDebug", defaultValue = "true") Boolean doDebug
                        )
        {
                // initialize variables for Protegrity
                String[] inputStringArray = new String[1];
                String[] UnProtectStringArray = new String[1];
                String unprotectedString = null;

                // instantiate call to protegrity protector
                Protector protector = null;
                try {
                        protector = Protector.getProtector();
                        if (doDebug) log.info("Protegrity Protector Instantiated");
                }
                catch (Exception e) {
                        log.info("Couldn't create instantiate Protegrity Protector: %s",e);
                }

                // create a protegrity session
                SessionObject session = null;
                try {
                        // get a protegrity session...hard coding the username to "neo4j" since that is the OS username
                        // that the database (and protegrity application protector elements) is running under
                        session = protector.createSession("neo4j");
                        if (doDebug) log.info("Protegrity session created");
                }
                catch (Exception e) {
                        log.info("Couldn't create create session with Protegrity: %s",e);
                }


                // call Protegrity to encrypt/protect data
                inputStringArray[0] = _protectedValue;
                try {
                        if(!protector.unprotect(session,_dataElement,inputStringArray,UnProtectStringArray))
                                log.info("Call to Protegrity protect API failed for element '%s' and value '%s'!!! \nError :%s",_dataElement,inputStringArray[0],protector.getLastError(session));
                        unprotectedString = UnProtectStringArray[0];
                        if (doDebug) log.info("Call to Protegrity protect API succeeded for element '%s' and value '%s' --> protected value: '%s'!!!",_dataElement,inputStringArray[0],unprotectedString);
                }
                catch (Exception e) {
                        log.info("Couldn't invoke data proection using element '%s' and value '%s' -> error: %s",_dataElement,inputStringArray[0],e);
                }

                return unprotectedString;
        }


        //##################################################################################################################


        @UserFunction("PROTECT_ACCOUNT_NUM")
        @Description("PROTECT_ACCOUNT_NUM - this function calls Protegrity to protect data for account numbers")
        public String PROTECT_ACCOUNT_NUM(
                @Name("AccountNumber") String accountNumber
        ) {
                // The DataElement is hardcoded based on the mapping table
                String dataElement = "dtStrNPL"; // The element used for account numbers
                // Call the protectData function with the hardcoded element and the passed account number
                return protectData(dataElement, accountNumber, true);
        }

        @UserFunction("UNPROTECT_ACCOUNT_NUM")
        @Description("UNPROTECT_ACCOUNT_NUM - this function calls Protegrity to unprotect data for account numbers")
        public String UNPROTECT_ACCOUNT_NUM(
                @Name("ProtectedAccountNumber") String protectedAccountNumber
        ) {
                // The DataElement is hardcoded based on the mapping table
                String dataElement = "dtStrNPL"; // The element used for account numbers
                // Call the unprotectData function with the hardcoded element and the passed account number
                return unprotectData(dataElement, protectedAccountNumber, true);
        }

        @UserFunction("PROTECT_NAME")
        @Description("PROTECT_NAME - this function calls Protegrity to protect data for names")
        public String PROTECT_NAME(
                @Name("Name") String name
        ) {
                // The DataElement is hardcoded based on the mapping table
                String dataElement = "dtStrNPL"; // The element used for names
                // Call the protectData function with the hardcoded element and the passed name
                return protectData(dataElement, name, true);
        }

        @UserFunction("UNPROTECT_NAME")
        @Description("UNPROTECT_NAME - this function calls Protegrity to unprotect data for names")
        public String UNPROTECT_NAME(
                @Name("ProtectedName") String protectedName
        ) {
                // The DataElement is hardcoded based on the mapping table
                String dataElement = "dtStrNPL"; // The element used for names
                // Call the unprotectData function with the hardcoded element and the passed name
                return unprotectData(dataElement, protectedName, true);
        }


        


//			if(!protector.reprotect(session,DE,DE,ProtectStringArray,ReProtectStringArray))
//				System.out.println("reprotect api failed !!! \nError :"+protector.getLastError(session));
//			else
//				System.out.println( "4.) ReProtect Output: " + ReProtectStringArray[0] );

}
